define( function ( require ) {

	"use strict";

	return {
		app_slug : 'ooshybooshy',
		wp_ws_url : 'http://ooshybooshy.com/wp-appkit-api/ooshybooshy',
		wp_url : 'http://ooshybooshy.com',
		theme : 'assets',
		version : '1.0',
		app_type : 'phonegap-build',
		app_title : 'ooshybooshy',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 5,
		debug_mode : 'off',
		auth_key : '!wqV|y X2hZI{Epn[(iW]th#z,Sc.9V!:qnXL,|JG(sCn*d|@`(C/Bgbu1)sJzdX',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
