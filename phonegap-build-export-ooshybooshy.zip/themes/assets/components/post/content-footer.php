	<footer class="entry-footer">
		<?php dara_entry_footer(); ?>
	</footer><!-- .entry-footer -->